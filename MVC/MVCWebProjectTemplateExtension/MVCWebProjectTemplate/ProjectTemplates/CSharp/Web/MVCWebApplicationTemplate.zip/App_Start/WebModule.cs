﻿using $safeprojectname$.Infrastructure;
using Ninject.Modules;

namespace $safeprojectname$
{
    public class WebModule : NinjectModule
    {
        public override void Load()
        {
            Bind<IDoThings>().To<DoThings>();
        }
    }
}