﻿using NUnit.Framework;

namespace $safeprojectname$
{
    [TestFixture]
    public class UnitTest1
    {
        [Test]
        public void TestMethod1()
        {
        }
    }
}
